import sqlite3


def create_table():
    conn = sqlite3.connect('employee1')

    c = conn.cursor()

    c.execute(
        '''CREATE TABLE IF NOT EXISTS employee (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, department TEXT)''')

    c.execute('''CREATE TABLE IF NOT EXISTS department (name TEXT)''')

    c.execute('''CREATE TABLE IF NOT EXISTS project (name TEXT)''')

    conn.commit()


create_table()
